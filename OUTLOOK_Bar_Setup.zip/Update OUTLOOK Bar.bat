@echo off
setlocal EnableExtensions
chcp 65001 >nul
title OUTLOOK Bar - install / update
rem  2026-08-07: also match renamed folders like "Outlook 1"; if the company
rem  folder is missing but the program is already installed, keep going
rem  (the bar updates program files from GitHub itself); when nothing is
rem  found, print a diagnosis screen the staff can send to Brian.

set "URL=https://ix.timelesscommercial.com.au/apps/OUTLOOK_bar.ahk"
set "ICOURL=https://ix.timelesscommercial.com.au/apps/outlook.ico"
set "NODEDIR=%LOCALAPPDATA%\node-lts"

rem  Find the Outlook folder (the one that contains src\index.js)
set "DESTDIR="
for %%D in (
  "%USERPROFILE%\OUTLOOK Bar\Outlook"
  "%OneDrive%\Document\GitHub\Outlook"
  "%OneDrive%\Documents\GitHub\Outlook"
  "%USERPROFILE%\OneDrive\Document\GitHub\Outlook"
  "%USERPROFILE%\OneDrive\Documents\GitHub\Outlook"
  "%USERPROFILE%\Documents\GitHub\Outlook"
  "%USERPROFILE%\Document\GitHub\Outlook"
  "%USERPROFILE%\Documents\Outlook"
  "%USERPROFILE%\GitHub\Outlook"
  "%USERPROFILE%\Outlook"
  "%USERPROFILE%\Desktop\Outlook"
  "%USERPROFILE%\Downloads\Outlook"
  "%OneDrive%\Documents\Outlook"
  "%OneDrive%\Document\Outlook"
  "%OneDrive%\Desktop\Outlook"
  "%OneDrive%\Outlook"
) do (
  if not defined DESTDIR if exist "%%~D\src\index.js" set "DESTDIR=%%~D"
)
rem  Staff copy: always refresh from the company folder (auto-update).
rem  Only the admin's own GitHub clone is left alone.
if defined DESTDIR (
  echo %DESTDIR% | find /i "GitHub" >nul || goto :findshared
)
rem  Also check the REAL Documents/Desktop folders (OneDrive-redirected PCs)
if defined DESTDIR goto :havefolder
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('MyDocuments'); [Environment]::GetFolderPath('Desktop'); [Environment]::GetFolderPath('UserProfile')+'\Downloads'"`) do (
  if not defined DESTDIR if exist "%%P\Outlook\src\index.js" set "DESTDIR=%%P\Outlook"
)
if defined DESTDIR goto :havefolder

rem  Locate the company shared copy (works for any OneDrive/SharePoint layout)
:findshared
set "SRCDIR="
for /f "usebackq delims=" %%S in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$mids=@('Timeless 042026 - Documents\Admin\Automation\Outlook','Admin\Automation\Outlook','Automation\Outlook','Timeless 042026 - Documents\Admin\Automation\OUTLOOK Bar\Outlook'); $roots=@($env:OneDriveCommercial,$env:OneDrive); Get-ChildItem $env:USERPROFILE -Directory -ErrorAction SilentlyContinue | ForEach-Object { $roots += $_.FullName }; foreach($r in $roots){ if(-not $r){continue}; foreach($m in $mids){ $p=Join-Path $r $m; if(Test-Path (Join-Path $p 'src\index.js')){ Write-Output $p; exit } } }"`) do if not defined SRCDIR set "SRCDIR=%%S"
if defined SRCDIR goto :havesrc
rem  Not in the usual spots - deeper scan (renamed OneDrive shortcuts, other layouts)
echo   Searching for the company Outlook folder... 1-2 min / 회사 Outlook 폴더 검색 중... 1~2분 걸릴 수 있어요
for /f "usebackq delims=" %%S in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$roots=@($env:OneDriveCommercial,$env:OneDrive); Get-ChildItem $env:USERPROFILE -Directory -ErrorAction SilentlyContinue | ForEach-Object { $roots += $_.FullName }; $roots = $roots | Where-Object { $_ -and ($_ -notmatch 'AppData$') } | Select-Object -Unique; foreach($r in $roots){ if(-not (Test-Path $r)){continue}; $hit = Get-ChildItem -Path $r -Directory -Recurse -Depth 5 -Filter 'Outlook*' -ErrorAction SilentlyContinue | Where-Object { $_.FullName -notmatch 'node_modules|OUTLOOK Bar|AppData|\.git' } | Where-Object { Test-Path (Join-Path $_.FullName 'src\index.js') } | Select-Object -First 1; if($hit){ Write-Output $hit.FullName; exit } }"`) do if not defined SRCDIR set "SRCDIR=%%S"
if defined SRCDIR goto :havesrc
rem  Company folder not found, but the program is already on this PC - keep going.
rem  Since v24 the bar refreshes the program files from GitHub by itself.
if defined DESTDIR (
  echo   Company folder not found - continuing with the copy already on this PC.
  echo   회사 폴더는 못 찾았지만 이미 설치된 프로그램이 있어 그걸로 계속합니다.
  goto :havefolder
)
goto :nofolder
:havesrc
echo   Getting the latest program from the company folder... / 회사 폴더에서 최신 프로그램 가져오는 중...
set "DESTDIR=%USERPROFILE%\OUTLOOK Bar\Outlook"
robocopy "%SRCDIR%" "%DESTDIR%" /E /XD node_modules reports .git .claude docs /XF tokens.json state.json log.txt "flagged-cache*.json" OUTLOOK_bar.ini >nul
if not exist "%DESTDIR%\src\index.js" goto :nofolder
:havefolder

set "DEST=%DESTDIR%\OUTLOOK_bar.ahk"
echo.
echo   OUTLOOK Bar - install / update
echo   Folder: %DESTDIR%
echo.

rem  ---- [1/3] Node.js (fully automatic - no admin rights needed) ----
where node >nul 2>nul
if not errorlevel 1 goto :havenode
if exist "%ProgramFiles%\nodejs\node.exe" (
  set "PATH=%ProgramFiles%\nodejs;%PATH%"
  goto :havenode
)
if exist "%NODEDIR%\node.exe" (
  set "PATH=%NODEDIR%;%PATH%"
  goto :havenode
)
echo   [1/3] Installing Node.js... please wait 1-3 min, do NOT close this window
echo          Node.js 설치 중... 1~3분 걸려요. 창을 닫지 마세요
set "NARCH=win-x64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "NARCH=win-arm64"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $b='https://nodejs.org/dist/latest-v24.x/'; $s=(Invoke-WebRequest -UseBasicParsing ($b+'SHASUMS256.txt')).Content; $n=[regex]::Match($s,'node-v[0-9.]+-%NARCH%\.zip').Value; if(-not $n){exit 1}; $z=Join-Path $env:TEMP 'node-lts.zip'; Invoke-WebRequest -UseBasicParsing ($b+$n) -OutFile $z; $t=Join-Path $env:TEMP 'node-lts-unzip'; if(Test-Path $t){Remove-Item $t -Recurse -Force}; Expand-Archive -Path $z -DestinationPath $t -Force; $i=Get-ChildItem $t -Directory | Select-Object -First 1; $d='%NODEDIR%'; if(Test-Path $d){Remove-Item $d -Recurse -Force}; Move-Item $i.FullName $d; Remove-Item $z -Force; Remove-Item $t -Recurse -Force"
if exist "%NODEDIR%\node.exe" (
  set "PATH=%NODEDIR%;%PATH%"
  goto :havenode
)
goto :nodefail
:havenode
rem  Make portable Node available to the bar later too (user PATH, one time)
if exist "%NODEDIR%\node.exe" powershell -NoProfile -ExecutionPolicy Bypass -Command "$d='%NODEDIR%'; $p=[Environment]::GetEnvironmentVariable('Path','User'); if(-not $p){$p=''}; if($p -notlike ('*'+$d+'*')){[Environment]::SetEnvironmentVariable('Path',($p.TrimEnd(';')+';'+$d),'User')}"

rem  ---- [2/3] npm install (first time only) ----
if exist "%DESTDIR%\node_modules" goto :havedeps
echo   [2/3] Preparing files... (one time, 1-3 min / 처음 한 번, 1~3분)
pushd "%DESTDIR%"
call npm install
popd
:havedeps

rem  ---- Microsoft sign-in (once per PC) - the bar reads mail through the cloud (Graph),
rem       so it works with classic AND new Outlook, even when Outlook is closed.
set "LOGINSTATE="
for /f "usebackq delims=" %%L in (`node "%DESTDIR%\src\index.js" --check-login 2^>nul`) do set "LOGINSTATE=%%L"
if /i "%LOGINSTATE%"=="LOGIN=ok" goto :haveauth
echo.
echo   Sign in to your company email (one time). A code will appear below -
echo   a browser window opens; sign in with your work email and enter the code.
echo   회사 메일 로그인 (처음 한 번). 아래에 코드가 나오면, 열리는 브라우저에서
echo   회사 메일로 로그인한 뒤 그 코드를 입력하세요.
echo.
start https://microsoft.com/devicelogin
pushd "%DESTDIR%"
node src\index.js --login
popd
:haveauth


rem  ---- AutoHotkey v2 (auto install if missing - no admin needed) ----
call :findahk
if defined AHKEXE goto :haveahk
echo   Installing AutoHotkey... (one time, 1 min / 자동 설치 - 처음 한 번, 1분)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -UseBasicParsing 'https://www.autohotkey.com/download/ahk-v2.exe' -OutFile ($env:TEMP+'\ahk-v2-setup.exe'); exit 0 } catch { exit 1 }"
if not exist "%TEMP%\ahk-v2-setup.exe" goto :ahkfail
start /wait "" "%TEMP%\ahk-v2-setup.exe" /silent
call :findahk
if not defined AHKEXE goto :ahkfail
:haveahk

rem  ---- [3/3] download the latest bar (cache-busted) ----
echo   [3/3] Getting the latest bar...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -UseBasicParsing -Uri ('%URL%?v=' + (Get-Random)) -OutFile '%DEST%'; exit 0 } catch { exit 1 }"
if errorlevel 1 goto :dlfail

rem  Outlook logo for the desktop shortcut (best effort)
if not exist "%DESTDIR%\outlook.ico" powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; try { [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri ('%ICOURL%?v=' + (Get-Random)) -OutFile '%DESTDIR%\outlook.ico' } catch {}"

rem  Desktop shortcut (with Outlook icon when available)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $l=$w.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\OUTLOOK Bar.lnk'); $l.TargetPath='%DEST%'; $l.WorkingDirectory='%DESTDIR%'; if(Test-Path '%DESTDIR%\outlook.ico'){$l.IconLocation='%DESTDIR%\outlook.ico,0'}; $l.Save()"
ie4uinit.exe -show >nul 2>nul

echo.
echo   Done! Starting the bar... / 완료! 바를 켭니다...
start "" "%AHKEXE%" "%DEST%"
timeout /t 3 >nul
exit /b 0

:findahk
set "AHKEXE="
if exist "%LocalAppData%\Programs\AutoHotkey\v2\AutoHotkey64.exe" set "AHKEXE=%LocalAppData%\Programs\AutoHotkey\v2\AutoHotkey64.exe"
if not defined AHKEXE if exist "%ProgramFiles%\AutoHotkey\v2\AutoHotkey64.exe" set "AHKEXE=%ProgramFiles%\AutoHotkey\v2\AutoHotkey64.exe"
if not defined AHKEXE if exist "%LocalAppData%\Programs\AutoHotkey\v2\AutoHotkey32.exe" set "AHKEXE=%LocalAppData%\Programs\AutoHotkey\v2\AutoHotkey32.exe"
if not defined AHKEXE if exist "%ProgramFiles%\AutoHotkey\v2\AutoHotkey32.exe" set "AHKEXE=%ProgramFiles%\AutoHotkey\v2\AutoHotkey32.exe"
exit /b 0

:ahkfail
echo.
echo   Could not install AutoHotkey automatically.
echo   A download page will open - install v2, then run this file again.
echo   AutoHotkey 자동 설치에 실패했어요. 열리는 페이지에서 v2 설치 후 다시 실행하세요.
echo.
start https://www.autohotkey.com
pause
exit /b 1

:nofolder
echo.
echo   OUTLOOK program not found on this PC yet.
echo   1^) Open the company SharePoint site in the browser:
echo      Documents ^> Admin ^> Automation ^> Outlook
echo   2^) Click "Sync" or "Add shortcut to OneDrive" on that folder.
echo   3^) Wait a few minutes for OneDrive, then run this file again.
echo   If it still fails, contact the admin.
echo.
echo   이 PC에서 OUTLOOK 프로그램을 아직 못 찾았어요.
echo   1^) 브라우저에서 회사 SharePoint 사이트를 열고:
echo      문서 ^> Admin ^> Automation ^> Outlook
echo   2^) 그 폴더에서 "동기화(Sync)" 또는 "OneDrive에 바로가기 추가"를 누르세요.
echo   3^) OneDrive 동기화가 끝나길 몇 분 기다렸다가 이 파일을 다시 실행하세요.
echo   계속 안 되면 관리자(Brian)에게 알려주세요.
echo.
echo   Checking why... 1-2 min / 왜 안 되는지 확인 중... 1~2분
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; Write-Output ''; Write-Output '  --- 진단 / Diagnosis ---'; if($env:OneDriveCommercial){Write-Output ('  company OneDrive: '+$env:OneDriveCommercial)}else{Write-Output '  company OneDrive: NOT SIGNED IN / 회사 OneDrive 로그인이 안 되어 있어요 - OneDrive에 회사 메일로 로그인하세요'}; if($env:OneDrive){Write-Output ('  OneDrive        : '+$env:OneDrive)}; $roots=@($env:OneDriveCommercial,$env:OneDrive); Get-ChildItem $env:USERPROFILE -Directory | ForEach-Object { $roots += $_.FullName }; $roots=$roots | Where-Object { $_ -and (Test-Path $_) -and ($_ -notmatch 'AppData$') } | Select-Object -Unique; $hits=@(); foreach($r in $roots){ Get-ChildItem -Path $r -Directory -Recurse -Depth 5 -Filter 'Outlook*' | Where-Object { $_.FullName -notmatch 'node_modules|AppData|\.git' } | ForEach-Object { $hits += $_.FullName } }; $hits=$hits | Select-Object -Unique; Write-Output '  Outlook folders on this PC / 이 PC에서 찾은 Outlook 폴더:'; if(@($hits).Count -eq 0){ Write-Output '    none / 없음 - 동기화가 아직 안 됐거나 다른 폴더를 동기화했을 수 있어요' } else { foreach($h in $hits){ if(Test-Path (Join-Path $h 'src\index.js')){ Write-Output ('    [program OK] '+$h) } else { Write-Output ('    [src missing / src 없음] '+$h) } } }"
echo.
echo   * Take a photo of this window and send it to Brian.
echo   * 이 창을 캡처해서 Brian에게 보내주세요.
echo.
pause
exit /b 1

:nodefail
echo.
echo   Could not install Node.js automatically.
echo   A download page will open - install it, then run this file again.
echo   Node.js 자동 설치에 실패했어요. 열리는 페이지에서 설치 후 다시 실행하세요.
echo.
start https://nodejs.org
pause
exit /b 1

:dlfail
echo.
echo   Download FAILED. Check your internet connection and run this again.
echo   다운로드 실패 - 인터넷 확인 후 다시 실행하세요.
echo.
pause
exit /b 1
